import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

// Types
interface MessageAnalysis {
  message: string;
  sender: 'user' | 'other';
  interestLevel: number;
  engagement: 'high' | 'medium' | 'low';
  redFlags: string[];
  greenFlags: string[];
  interpretation: string;
}

interface ConversationStats {
  totalMessages: number;
  userMessages: number;
  otherMessages: number;
  averageUserLength: number;
  averageOtherLength: number;
  whoInitiates: 'user' | 'other' | 'balanced';
  whoRelances: 'user' | 'other' | 'balanced';
  userQuestionCount: number;
  otherQuestionCount: number;
  emojiUsage: { user: number; other: number };
}

interface AnalysisResult {
  interestScore: number;
  manipulationScore: number;
  ghostingScore: number;
  overallScore: number;
  advice: string;
  punchline: string;
  highlights: {
    positive: string[];
    negative: string[];
    neutral: string[];
  };
  vibe: string;
  badges: string[];
  messageAnalysis: MessageAnalysis[];
  conversationStats: ConversationStats;
  evolutionScore: {
    start: number;
    middle: number;
    end: number;
    trend: 'improving' | 'stable' | 'declining';
  };
  redFlagsDetected: string[];
  greenFlagsDetected: string[];
  personalityInsight: string;
}

// Context options
const RELATIONSHIP_CONTEXTS = [
  { id: 'crush', label: 'Crush secret', emoji: '😍' },
  { id: 'ex', label: 'Ex', emoji: '💔' },
  { id: 'new', label: 'Début de relation', emoji: '✨' },
  { id: 'talking', label: 'Talking stage', emoji: '💬' },
  { id: 'situationship', label: 'Situationship', emoji: '🤷' },
];

// Secure JSON extraction with regex
function extractJSON(text: string): string | null {
  // Try to find JSON object with regex
  const jsonRegex = /\{[\s\S]*\}/;
  const match = text.match(jsonRegex);
  return match ? match[0] : null;
}

// Calculate overall score based on weighted formula
function calculateOverallScore(interest: number, ghosting: number, manipulation: number): number {
  // Formula: Interest is good, Ghosting and Manipulation are bad
  const score = (interest * 0.5) - (ghosting * 0.3) - (manipulation * 0.2);
  return Math.max(0, Math.min(100, Math.round(score)));
}

// Analyze conversation stats locally
function analyzeConversationStats(conversation: string): ConversationStats {
  const lines = conversation.split('\n').filter(line => line.trim().length > 0);
  
  let userMessages = 0;
  let otherMessages = 0;
  let userTotalLength = 0;
  let otherTotalLength = 0;
  let userQuestions = 0;
  let otherQuestions = 0;
  let userEmojis = 0;
  let otherEmojis = 0;
  
  const emojiRegex = /[\u{1F300}-\u{1F9FF}]|[\u{2600}-\u{26FF}]|[\u{2700}-\u{27BF}]/gu;
  const questionRegex = /\?/g;
  
  // Common patterns to identify who is speaking
  const userPatterns = /^(moi|toi|me|moi:|to i:|je |j'|hey|salut|coucou)/i;
  const otherPatterns = /^(lui|elle|him|her|il |elle |il:|elle:)/i;
  
  let isFirstUserMessage = true;
  let isFirstOtherMessage = true;
  let userInitiated = false;
  let otherInitiated = false;
  let userRelances = 0;
  let otherRelances = 0;
  
  let lastSender: 'user' | 'other' | null = null;
  
  lines.forEach((line, index) => {
    const cleanLine = line.replace(/^(moi|toi|lui|elle|him|her|me):\s*/i, '').trim();
    const isUser = userPatterns.test(line) || (!otherPatterns.test(line) && index % 2 === 0);
    const isOther = otherPatterns.test(line);
    
    const emojis = (cleanLine.match(emojiRegex) || []).length;
    const questions = (cleanLine.match(questionRegex) || []).length;
    
    if (isUser || (!isOther && index % 2 === 0)) {
      userMessages++;
      userTotalLength += cleanLine.length;
      userQuestions += questions;
      userEmojis += emojis;
      
      if (isFirstUserMessage) {
        userInitiated = true;
        isFirstUserMessage = false;
      }
      
      // Check for relance (user sending after other)
      if (lastSender === 'other') {
        userRelances++;
      }
      lastSender = 'user';
    } else {
      otherMessages++;
      otherTotalLength += cleanLine.length;
      otherQuestions += questions;
      otherEmojis += emojis;
      
      if (isFirstOtherMessage) {
        otherInitiated = true;
        isFirstOtherMessage = false;
      }
      
      if (lastSender === 'user') {
        otherRelances++;
      }
      lastSender = 'other';
    }
  });
  
  const total = userMessages + otherMessages;
  
  return {
    totalMessages: total,
    userMessages,
    otherMessages,
    averageUserLength: userMessages > 0 ? Math.round(userTotalLength / userMessages) : 0,
    averageOtherLength: otherMessages > 0 ? Math.round(otherTotalLength / otherMessages) : 0,
    whoInitiates: userInitiated && !otherInitiated ? 'user' : otherInitiated && !userInitiated ? 'other' : 'balanced',
    whoRelances: userRelances > otherRelances * 1.5 ? 'user' : otherRelances > userRelances * 1.5 ? 'other' : 'balanced',
    userQuestionCount: userQuestions,
    otherQuestionCount: otherQuestions,
    emojiUsage: { user: userEmojis, other: otherEmojis }
  };
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { conversation, platform, context } = body;

    // Validation
    if (!conversation || typeof conversation !== 'string') {
      return NextResponse.json(
        { error: 'Conversation requise' },
        { status: 400 }
      );
    }

    if (conversation.length < 20) {
      return NextResponse.json(
        { error: 'Conversation trop courte. Ajoute plus de messages !' },
        { status: 400 }
      );
    }

    if (conversation.length > 8000) {
      return NextResponse.json(
        { error: 'Conversation trop longue. Maximum 8000 caractères.' },
        { status: 400 }
      );
    }

    // Analyze stats locally first
    const stats = analyzeConversationStats(conversation);

    const zai = await ZAI.create();

    // Enhanced system prompt with deep analysis
    const systemPrompt = `Tu es GhostMeter, un expert en communication et relations amoureuses avec un style fun et engageant pour Gen Z.

Tu analyses les conversations de dating/messaging avec une précision chirurgicale.

TON RÔLE:
1. Analyser CHAQUE message individuellement
2. Détecter les patterns subtils (hot/cold, bread-crumbing, gaslighting)
3. Évaluer l'évolution de l'intérêt dans le temps
4. Donner des conseils ultra-personnalisés et actionables
5. Utiliser un ton décontracté avec emojis, mais rester précis

ANALYSE APPROFONDIE À FAIRE:

📊 Dynamiques de conversation:
- Qui initie le plus ? (= plus investi)
- Qui écrit les messages les plus longs ? (= effort)
- Qui pose le plus de questions ? (= intérêt réel)
- Y a-t-il un déséquilibre évident ?

📈 Évolution temporelle:
- Compare le début vs la fin de conversation
- L'intérêt augmente ou diminue ?
- Y a-t-il des signes de désengagement progressif ?

🚩 Red Flags à détecter:
- Hot/cold behavior (tantôt chaud, tantôt froid)
- Réponses tardives sans excuse
- Évitement des questions personnelles
- Never asks about you
- "Maybe" sans jamais s'engager
- Réponses monosyllabiques répétées

✅ Green Flags à détecter:
- Pose des questions sur toi
- Répond rapidement
- Utilise des emojis affectueux
- Initie les conversations
- Se souvient des détails
- Fait des plans pour se voir

Pour CHAQUE message, évalue:
- Niveau d'intérêt (0-100)
- Niveau d'engagement (high/medium/low)
- Red flags détectés (liste)
- Green flags détectés (liste)
- Interprétation en 1 phrase

CONTEXTE: ${context ? `La relation est: ${context}` : 'Contexte non spécifié'}

RÉPONDS UNIQUEMENT avec un JSON valide dans ce format exact:
{
  "interestScore": number (0-100),
  "manipulationScore": number (0-100),
  "ghostingScore": number (0-100),
  "advice": "string (conseil ultra-personnalisé de 2-3 phrases, avec exemple concret de la conversation)",
  "punchline": "string (UNE phrase courte et percutante, style viral TikTok, max 100 caractères)",
  "highlights": {
    "positive": ["point positif spécifique avec exemple"],
    "negative": ["point négatif spécifique avec exemple"],
    "neutral": ["observation factuelle"]
  },
  "vibe": "string (description courte du vibe global)",
  "badges": ["badge 1", "badge 2"],
  "messageAnalysis": [
    {
      "message": "extrait court du message",
      "sender": "user ou other",
      "interestLevel": number (0-100),
      "engagement": "high/medium/low",
      "redFlags": ["flag1"],
      "greenFlags": ["flag1"],
      "interpretation": "string"
    }
  ],
  "evolutionScore": {
    "start": number (0-100),
    "middle": number (0-100),
    "end": number (0-100),
    "trend": "improving/stable/declining"
  },
  "redFlagsDetected": ["flag global 1", "flag global 2"],
  "greenFlagsDetected": ["flag global 1", "flag global 2"],
  "personalityInsight": "string (analyse de la personnalité de l'autre personne en 2-3 phrases)"
}

BADGES DISPONIBLES (choisis 1-3):
- "💘 Crush Confirmé"
- "🚩 Red Flag Alert"
- "👻 Ghosting Imminent"
- "💕 Mutual Interest"
- "🤷 Mixed Signals"
- "🔥 High Chemistry"
- "❄️ Cold Texter"
- "🎭 Player Vibes"
- "✨ Green Flags"
- "📱 Good Texter"
- "😴 Boring Conversations"
- "🎯 Clear Intentions"
- "🏃 Run Away"
- "💎 Keep Him/Her"
- "🎪 Drama Queen/King"
- "🧊 Ice Age"

PUNCHLINE EXEMPLES:
- "Il te breadcrumb, pas il te want."
- "Run. 🏃‍♀️"
- "Il/elle est interested... à 40%."
- "Situationship inbound 🚨"
- "Ghosting dans 3, 2, 1..."

SOIS PRÉCIS ET CITE DES EXEMPLES DE LA CONVERSATION!`;

    const userPrompt = `Analyse cette conversation ${platform ? `de ${platform}` : ''} (Contexte: ${context || 'non spécifié'}):

${conversation}

Donne-moi l'analyse COMPLÈTE avec message par message.`;

    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt }
      ],
      temperature: 0.7,
      max_tokens: 3000
    });

    const responseContent = completion.choices[0]?.message?.content;
    
    if (!responseContent) {
      throw new Error('Pas de réponse de l\'IA');
    }

    // Secure JSON extraction with regex
    const jsonStr = extractJSON(responseContent);
    
    if (!jsonStr) {
      console.error('No JSON found in response:', responseContent.substring(0, 500));
      throw new Error('Impossible d\'extraire les données de l\'analyse');
    }

    let analysis: AnalysisResult;
    try {
      analysis = JSON.parse(jsonStr);
    } catch (parseError) {
      console.error('JSON Parse Error:', parseError);
      console.error('JSON string was:', jsonStr.substring(0, 500));
      throw new Error('Erreur de parsing des résultats');
    }
    
    // Validate and clamp scores
    analysis.interestScore = Math.max(0, Math.min(100, Number(analysis.interestScore) || 50));
    analysis.manipulationScore = Math.max(0, Math.min(100, Number(analysis.manipulationScore) || 30));
    analysis.ghostingScore = Math.max(0, Math.min(100, Number(analysis.ghostingScore) || 30));
    
    // RECALCULATE overall score with weighted formula
    analysis.overallScore = calculateOverallScore(
      analysis.interestScore,
      analysis.ghostingScore,
      analysis.manipulationScore
    );

    // Add local stats to analysis
    analysis.conversationStats = stats;

    // Ensure arrays exist
    analysis.redFlagsDetected = analysis.redFlagsDetected || [];
    analysis.greenFlagsDetected = analysis.greenFlagsDetected || [];
    analysis.messageAnalysis = analysis.messageAnalysis || [];
    
    // Ensure evolution score exists with defaults
    analysis.evolutionScore = analysis.evolutionScore || {
      start: analysis.interestScore,
      middle: analysis.interestScore,
      end: analysis.interestScore,
      trend: 'stable'
    };

    // Validate evolution score values
    analysis.evolutionScore.start = Math.max(0, Math.min(100, Number(analysis.evolutionScore.start) || analysis.interestScore));
    analysis.evolutionScore.middle = Math.max(0, Math.min(100, Number(analysis.evolutionScore.middle) || analysis.interestScore));
    analysis.evolutionScore.end = Math.max(0, Math.min(100, Number(analysis.evolutionScore.end) || analysis.interestScore));

    // Generate punchline if missing
    if (!analysis.punchline) {
      if (analysis.overallScore >= 70) {
        analysis.punchline = "Il/elle est interested ! 💕";
      } else if (analysis.overallScore >= 40) {
        analysis.punchline = "Mixed signals... 🤷";
      } else {
        analysis.punchline = "Red flag alert 🚩";
      }
    }

    // Generate personality insight if missing
    if (!analysis.personalityInsight) {
      analysis.personalityInsight = analysis.advice || "Analyse non disponible";
    }

    return NextResponse.json({ 
      success: true, 
      analysis 
    });

  } catch (error) {
    console.error('Analysis Error:', error);
    
    return NextResponse.json(
      { 
        error: 'Erreur lors de l\'analyse. Réessaie dans un instant ! 👻',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}
