'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Heart, AlertTriangle, Ghost, Sparkles, Crown, 
  Copy, Check, Zap, Shield, TrendingUp, MessageCircle,
  RefreshCw, Menu, History, Share2, ChevronLeft, Trash2,
  ArrowUp, ArrowDown, Minus, MessageSquare, Clock, Users
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Separator } from '@/components/ui/separator'
import { useToast } from '@/hooks/use-toast'
import { Progress } from '@/components/ui/progress'
import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from "@/components/ui/drawer"

// Types
interface MessageAnalysis {
  message: string;
  sender: 'user' | 'other';
  interestLevel: number;
  engagement: 'high' | 'medium' | 'low';
  redFlags: string[];
  greenFlags: string[];
  interpretation: string;
}

interface ConversationStats {
  totalMessages: number;
  userMessages: number;
  otherMessages: number;
  averageUserLength: number;
  averageOtherLength: number;
  whoInitiates: 'user' | 'other' | 'balanced';
  whoRelances: 'user' | 'other' | 'balanced';
  userQuestionCount: number;
  otherQuestionCount: number;
  emojiUsage: { user: number; other: number };
}

interface EvolutionScore {
  start: number;
  middle: number;
  end: number;
  trend: 'improving' | 'stable' | 'declining';
}

interface AnalysisResult {
  interestScore: number;
  manipulationScore: number;
  ghostingScore: number;
  overallScore: number;
  advice: string;
  punchline: string;
  highlights: {
    positive: string[];
    negative: string[];
    neutral: string[];
  };
  vibe: string;
  badges: string[];
  messageAnalysis: MessageAnalysis[];
  conversationStats: ConversationStats;
  evolutionScore: EvolutionScore;
  redFlagsDetected: string[];
  greenFlagsDetected: string[];
  personalityInsight: string;
  platform?: string;
  context?: string;
  date?: string;
}

type AppState = 'home' | 'analyzing' | 'results' | 'premium' | 'history'

// Platform options
const platforms = [
  { id: 'whatsapp', name: 'WhatsApp', icon: '💬', gradient: 'from-green-400 to-green-600' },
  { id: 'messenger', name: 'Messenger', icon: '💙', gradient: 'from-blue-400 to-blue-600' },
  { id: 'instagram', name: 'Instagram', icon: '📸', gradient: 'from-purple-400 via-pink-500 to-orange-400' },
  { id: 'snapchat', name: 'Snapchat', icon: '👻', gradient: 'from-yellow-300 to-yellow-500' },
  { id: 'other', name: 'Autre', icon: '📱', gradient: 'from-gray-400 to-gray-600' },
]

// Relationship contexts
const relationshipContexts = [
  { id: 'crush', label: 'Crush secret', emoji: '😍', desc: 'Tu limes secrètement' },
  { id: 'ex', label: 'Ex', emoji: '💔', desc: 'Ancien(ne) partenaire' },
  { id: 'new', label: 'Début relation', emoji: '✨', desc: 'Ça commence' },
  { id: 'talking', label: 'Talking stage', emoji: '💬', desc: 'Vous parlez sans label' },
  { id: 'situationship', label: 'Situationship', emoji: '🤷', desc: 'Flou artistique' },
]

// Ghost Logo Component
function GhostLogo({ size = 80, animated = true }: { size?: number; animated?: boolean }) {
  return (
    <motion.div
      className="relative"
      animate={animated ? { y: [0, -8, 0] } : {}}
      transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
    >
      <svg
        width={size}
        height={size}
        viewBox="0 0 100 100"
        className="drop-shadow-lg"
      >
        <defs>
          <linearGradient id="ghostGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#a855f7" />
            <stop offset="50%" stopColor="#ec4899" />
            <stop offset="100%" stopColor="#8b5cf6" />
          </linearGradient>
        </defs>
        <path
          d="M50 10 C25 10 15 35 15 55 L15 85 C15 85 20 80 25 85 C30 90 35 85 40 85 C45 85 45 90 50 85 C55 80 55 85 60 85 C65 85 70 90 75 85 C80 80 85 85 85 85 L85 55 C85 35 75 10 50 10 Z"
          fill="url(#ghostGradient)"
        />
        <ellipse cx="35" cy="45" rx="8" ry="10" fill="white" />
        <ellipse cx="65" cy="45" rx="8" ry="10" fill="white" />
        <circle cx="37" cy="47" r="4" fill="#1a1a2e" />
        <circle cx="67" cy="47" r="4" fill="#1a1a2e" />
        <ellipse cx="25" cy="60" rx="6" ry="3" fill="#f472b6" opacity="0.6" />
        <ellipse cx="75" cy="60" rx="6" ry="3" fill="#f472b6" opacity="0.6" />
        <path d="M40 65 Q50 75 60 65" stroke="#1a1a2e" strokeWidth="3" fill="none" strokeLinecap="round" />
      </svg>
    </motion.div>
  )
}

// Score Circle Component
function ScoreCircle({ score, label, icon, color, delay = 0, size = 'normal' }: { 
  score: number; label: string; icon: string; color: string; delay?: number; size?: 'small' | 'normal' 
}) {
  const radius = size === 'small' ? 35 : 45
  const circumference = 2 * Math.PI * radius
  const strokeDashoffset = circumference - (score / 100) * circumference
  const center = size === 'small' ? 44 : 56

  return (
    <motion.div
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ delay, duration: 0.5, type: "spring" }}
      className="flex flex-col items-center"
    >
      <div className={`relative ${size === 'small' ? 'w-20 h-20' : 'w-24 h-24 sm:w-28 sm:h-28'}`}>
        <svg className="w-full h-full transform -rotate-90">
          <circle cx={center} cy={center} r={radius} fill="none" stroke="currentColor" strokeWidth="8" className="text-muted/30" />
          <motion.circle
            cx={center} cy={center} r={radius} fill="none" stroke={color} strokeWidth="8" strokeLinecap="round"
            strokeDasharray={circumference}
            initial={{ strokeDashoffset: circumference }}
            animate={{ strokeDashoffset }}
            transition={{ delay: delay + 0.3, duration: 1, ease: "easeOut" }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className={`font-bold ${size === 'small' ? 'text-lg' : 'text-xl sm:text-2xl'}`}>{Math.round(score)}%</span>
          <span className="text-base">{icon}</span>
        </div>
      </div>
      <span className="mt-1 text-xs sm:text-sm font-medium text-muted-foreground">{label}</span>
    </motion.div>
  )
}

// Evolution Chart Component
function EvolutionChart({ evolution }: { evolution: EvolutionScore }) {
  const getTrendIcon = () => {
    if (evolution.trend === 'improving') return <ArrowUp className="w-4 h-4 text-green-500" />
    if (evolution.trend === 'declining') return <ArrowDown className="w-4 h-4 text-red-500" />
    return <Minus className="w-4 h-4 text-yellow-500" />
  }

  const getTrendColor = () => {
    if (evolution.trend === 'improving') return 'text-green-500'
    if (evolution.trend === 'declining') return 'text-red-500'
    return 'text-yellow-500'
  }

  return (
    <div className="bg-muted/50 rounded-xl p-4">
      <div className="flex items-center justify-between mb-3">
        <span className="text-sm font-medium">Évolution de l'intérêt</span>
        <div className={`flex items-center gap-1 ${getTrendColor()}`}>
          {getTrendIcon()}
          <span className="text-xs capitalize">{evolution.trend === 'improving' ? 'En hausse' : evolution.trend === 'declining' ? 'En baisse' : 'Stable'}</span>
        </div>
      </div>
      <div className="flex items-end justify-between gap-2 h-20">
        {[
          { label: 'Début', value: evolution.start },
          { label: 'Milieu', value: evolution.middle },
          { label: 'Fin', value: evolution.end }
        ].map((item, i) => (
          <div key={i} className="flex-1 flex flex-col items-center gap-1">
            <motion.div
              initial={{ height: 0 }}
              animate={{ height: `${item.value}%` }}
              transition={{ delay: i * 0.2, duration: 0.5 }}
              className="w-full bg-gradient-to-t from-purple-500 to-pink-500 rounded-t-lg min-h-[4px]"
            />
            <span className="text-xs text-muted-foreground">{item.label}</span>
            <span className="text-xs font-bold">{item.value}%</span>
          </div>
        ))}
      </div>
    </div>
  )
}

// Stats Cards Component
function StatsCards({ stats }: { stats: ConversationStats }) {
  const statItems = [
    { 
      icon: <MessageSquare className="w-4 h-4" />, 
      label: 'Messages', 
      value: stats.totalMessages,
      sub: `Toi: ${stats.userMessages} | Autre: ${stats.otherMessages}`
    },
    { 
      icon: <Users className="w-4 h-4" />, 
      label: 'Qui initie ?', 
      value: stats.whoInitiates === 'user' ? 'Toi' : stats.whoInitiates === 'other' ? 'Lui/Elle' : 'Équilibré',
      sub: stats.whoInitiates === 'user' ? 'Tu fais le premier pas' : stats.whoInitiates === 'other' ? 'Il/Elle vient vers toi' : 'Initiative partagée'
    },
    { 
      icon: <Clock className="w-4 h-4" />, 
      label: 'Longueur moyenne', 
      value: `${stats.averageUserLength} vs ${stats.averageOtherLength}`,
      sub: 'Toi vs Lui/Elle (caractères)'
    },
  ]

  return (
    <div className="grid grid-cols-3 gap-2">
      {statItems.map((item, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.1 }}
          className="bg-muted/50 rounded-xl p-3 text-center"
        >
          <div className="flex justify-center mb-1 text-purple-500">{item.icon}</div>
          <p className="text-xs text-muted-foreground">{item.label}</p>
          <p className="text-sm font-bold truncate">{item.value}</p>
          <p className="text-xs text-muted-foreground truncate">{item.sub}</p>
        </motion.div>
      ))}
    </div>
  )
}

// Message Analysis Card
function MessageAnalysisCard({ analysis, index }: { analysis: MessageAnalysis; index: number }) {
  const getEngagementColor = (engagement: string) => {
    switch (engagement) {
      case 'high': return 'bg-green-500'
      case 'medium': return 'bg-yellow-500'
      case 'low': return 'bg-red-500'
      default: return 'bg-gray-500'
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.05 }}
      className={`p-3 rounded-xl border ${analysis.sender === 'user' ? 'bg-purple-50 dark:bg-purple-950/30 border-purple-200 dark:border-purple-800' : 'bg-gray-50 dark:bg-gray-900/30 border-gray-200 dark:border-gray-800'}`}
    >
      <div className="flex items-start justify-between gap-2 mb-2">
        <div className="flex items-center gap-2">
          <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-muted">
            {analysis.sender === 'user' ? 'Toi' : 'Lui/Elle'}
          </span>
          <div className={`w-2 h-2 rounded-full ${getEngagementColor(analysis.engagement)}`} />
          <span className="text-xs text-muted-foreground capitalize">{analysis.engagement}</span>
        </div>
        <span className="text-xs font-bold">{analysis.interestLevel}%</span>
      </div>
      <p className="text-sm italic mb-2 truncate">"{analysis.message}"</p>
      <p className="text-xs text-muted-foreground">{analysis.interpretation}</p>
      {analysis.greenFlags.length > 0 && (
        <div className="flex flex-wrap gap-1 mt-2">
          {analysis.greenFlags.map((flag, i) => (
            <Badge key={i} variant="secondary" className="text-xs bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300">
              ✅ {flag}
            </Badge>
          ))}
        </div>
      )}
      {analysis.redFlags.length > 0 && (
        <div className="flex flex-wrap gap-1 mt-2">
          {analysis.redFlags.map((flag, i) => (
            <Badge key={i} variant="secondary" className="text-xs bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300">
              🚩 {flag}
            </Badge>
          ))}
        </div>
      )}
    </motion.div>
  )
}

// Rate limiting hook
function useRateLimit(maxPerDay: number = 3) {
  const [remaining, setRemaining] = useState(() => {
    if (typeof window === 'undefined') return maxPerDay
    const today = new Date().toDateString()
    const storedData = localStorage.getItem('ghostmeter_usage')
    if (storedData) {
      const data = JSON.parse(storedData)
      if (data.date === today) return Math.max(0, maxPerDay - data.count)
    }
    return maxPerDay
  })

  const [isPremium, setIsPremium] = useState(() => {
    if (typeof window === 'undefined') return false
    return localStorage.getItem('ghostmeter_premium') === 'true'
  })

  useEffect(() => {
    const today = new Date().toDateString()
    const storedData = localStorage.getItem('ghostmeter_usage')
    if (!storedData) {
      localStorage.setItem('ghostmeter_usage', JSON.stringify({ date: today, count: 0 }))
    } else {
      const data = JSON.parse(storedData)
      if (data.date !== today) localStorage.setItem('ghostmeter_usage', JSON.stringify({ date: today, count: 0 }))
    }
  }, [])

  const incrementUsage = () => {
    if (isPremium) return true
    const today = new Date().toDateString()
    const storedData = localStorage.getItem('ghostmeter_usage')
    if (storedData) {
      const data = JSON.parse(storedData)
      if (data.date === today) {
        if (data.count >= maxPerDay) return false
        const newCount = data.count + 1
        localStorage.setItem('ghostmeter_usage', JSON.stringify({ date: today, count: newCount }))
        setRemaining(Math.max(0, maxPerDay - newCount))
        return true
      }
    }
    localStorage.setItem('ghostmeter_usage', JSON.stringify({ date: today, count: 1 }))
    setRemaining(maxPerDay - 1)
    return true
  }

  return { remaining, isPremium, incrementUsage }
}

// History hook
function useHistory() {
  const [history, setHistory] = useState<AnalysisResult[]>(() => {
    if (typeof window === 'undefined') return []
    const stored = localStorage.getItem('ghostmeter_history')
    if (stored) {
      try { return JSON.parse(stored) }
      catch { return [] }
    }
    return []
  })

  const addToHistory = (result: AnalysisResult) => {
    const newEntry = { ...result, date: new Date().toISOString() }
    setHistory(prev => {
      const updated = [newEntry, ...prev].slice(0, 20)
      localStorage.setItem('ghostmeter_history', JSON.stringify(updated))
      return updated
    })
  }

  const clearHistory = () => {
    setHistory([])
    localStorage.removeItem('ghostmeter_history')
  }

  return { history, addToHistory, clearHistory }
}

// Mobile Header
function MobileHeader({ onMenuClick, showBack, onBack, title }: { 
  onMenuClick: () => void; showBack?: boolean; onBack?: () => void; title?: string 
}) {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/80 dark:bg-gray-950/80 backdrop-blur-lg border-b border-purple-100 dark:border-purple-900">
      <div className="flex items-center justify-between px-4 py-3 max-w-lg mx-auto">
        {showBack ? (
          <Button variant="ghost" size="icon" onClick={onBack} className="touch-manipulation">
            <ChevronLeft className="w-6 h-6" />
          </Button>
        ) : (
          <Button variant="ghost" size="icon" onClick={onMenuClick} className="touch-manipulation">
            <Menu className="w-6 h-6" />
          </Button>
        )}
        <div className="flex items-center gap-2">
          <GhostLogo size={32} animated={false} />
          <span className="font-bold text-lg bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">
            {title || 'GhostMeter'}
          </span>
        </div>
        <div className="w-10" />
      </div>
    </header>
  )
}

// Mobile Menu
function MobileMenu({ isOpen, onClose, onNavigate, remaining, isPremium }: { 
  isOpen: boolean; onClose: () => void; onNavigate: (state: AppState) => void; remaining: number; isPremium: boolean 
}) {
  return (
    <Drawer open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DrawerContent>
        <DrawerHeader>
          <DrawerTitle className="flex items-center gap-2">
            <GhostLogo size={40} animated={false} />
            GhostMeter
          </DrawerTitle>
        </DrawerHeader>
        <div className="p-4 space-y-2">
          <Button variant="ghost" className="w-full justify-start gap-3 h-14 text-left touch-manipulation" onClick={() => { onNavigate('home'); onClose() }}>
            <Sparkles className="w-5 h-5 text-purple-500" />
            <div>
              <p className="font-medium">Nouvelle Analyse</p>
              <p className="text-xs text-muted-foreground">{isPremium ? 'Illimitée' : `${remaining} restantes`}</p>
            </div>
          </Button>
          <Button variant="ghost" className="w-full justify-start gap-3 h-14 text-left touch-manipulation" onClick={() => { onNavigate('history'); onClose() }}>
            <History className="w-5 h-5 text-blue-500" />
            <div><p className="font-medium">Historique</p><p className="text-xs text-muted-foreground">Tes analyses passées</p></div>
          </Button>
          <Button variant="ghost" className="w-full justify-start gap-3 h-14 text-left touch-manipulation" onClick={() => { onNavigate('premium'); onClose() }}>
            <Crown className="w-5 h-5 text-yellow-500" />
            <div><p className="font-medium">Premium</p><p className="text-xs text-muted-foreground">Analyses illimitées</p></div>
          </Button>
        </div>
        <DrawerFooter>
          <DrawerClose asChild><Button variant="outline" className="touch-manipulation">Fermer</Button></DrawerClose>
        </DrawerFooter>
      </DrawerContent>
    </Drawer>
  )
}

// Platform Selector
function PlatformSelector({ selected, onSelect }: { selected: string; onSelect: (id: string) => void }) {
  return (
    <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide -mx-4 px-4">
      {platforms.map((platform) => (
        <motion.button
          key={platform.id}
          whileTap={{ scale: 0.95 }}
          onClick={() => onSelect(platform.id)}
          className={`flex-shrink-0 flex flex-col items-center gap-1 p-3 rounded-xl transition-all touch-manipulation ${
            selected === platform.id ? `bg-gradient-to-br ${platform.gradient} text-white shadow-lg` : 'bg-muted/50 hover:bg-muted'
          }`}
        >
          <span className="text-2xl">{platform.icon}</span>
          <span className="text-xs font-medium">{platform.name}</span>
        </motion.button>
      ))}
    </div>
  )
}

// Context Selector
function ContextSelector({ selected, onSelect }: { selected: string; onSelect: (id: string) => void }) {
  return (
    <div className="space-y-2">
      <p className="text-sm font-medium text-muted-foreground">Contexte de la relation :</p>
      <div className="flex flex-wrap gap-2">
        {relationshipContexts.map((ctx) => (
          <motion.button
            key={ctx.id}
            whileTap={{ scale: 0.95 }}
            onClick={() => onSelect(ctx.id)}
            className={`flex items-center gap-2 px-3 py-2 rounded-xl text-sm transition-all touch-manipulation ${
              selected === ctx.id ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-md' : 'bg-muted/50 hover:bg-muted'
            }`}
          >
            <span>{ctx.emoji}</span>
            <span>{ctx.label}</span>
          </motion.button>
        ))}
      </div>
    </div>
  )
}

// Home Page
function HomePage({ onAnalyze, isLoading, onPremium, remaining, isPremium }: { 
  onAnalyze: (text: string, platform: string, context: string) => void
  isLoading: boolean
  onPremium: () => void
  remaining: number
  isPremium: boolean
}) {
  const [conversation, setConversation] = useState('')
  const [selectedPlatform, setSelectedPlatform] = useState('whatsapp')
  const [selectedContext, setSelectedContext] = useState('crush')
  const [charCount, setCharCount] = useState(0)
  const { incrementUsage } = useRateLimit(3)
  const { toast } = useToast()

  useEffect(() => { setCharCount(conversation.length) }, [conversation])

  const handleAnalyze = () => {
    if (!incrementUsage()) {
      toast({ title: "Limite atteinte ! 👻", description: "Passe Premium pour des analyses illimitées !", variant: "destructive" })
      return
    }
    if (conversation.trim().length >= 20) {
      onAnalyze(conversation, selectedPlatform, selectedContext)
    }
  }

  return (
    <div className="flex flex-col min-h-screen pt-16 pb-4">
      <div className="flex-1 flex flex-col items-center justify-center p-4">
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-4">
          <GhostLogo size={70} />
          <h1 className="text-2xl sm:text-3xl font-bold mt-3 bg-gradient-to-r from-purple-500 via-pink-500 to-violet-500 bg-clip-text text-transparent">
            GhostMeter
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">Découvre si ton crush t'aime vraiment 👻</p>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} transition={{ delay: 0.2 }} className="w-full max-w-md">
          <Card className="border-2 border-purple-200 dark:border-purple-800 shadow-xl">
            <CardHeader className="text-center pb-1 pt-3">
              <CardTitle className="text-base flex items-center justify-center gap-2">
                <Sparkles className="w-4 h-4 text-purple-500" />
                Colle ta conversation
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 pt-0">
              <PlatformSelector selected={selectedPlatform} onSelect={setSelectedPlatform} />
              <ContextSelector selected={selectedContext} onSelect={setSelectedContext} />
              <div className="relative">
                <Textarea
                  placeholder="Colle ta conversation ici...

Exemple:
Toi: Hey ! Tu fais quoi ? 😊
Lui/Elle: Rien de spécial, et toi ?
Toi: Je pensais aller au ciné, tu viens ?"
                  value={conversation}
                  onChange={(e) => setConversation(e.target.value)}
                  className="min-h-[140px] resize-none text-sm"
                  maxLength={8000}
                />
                <div className="absolute bottom-2 right-2 text-xs text-muted-foreground">{charCount}/8000</div>
              </div>
              <Button
                onClick={handleAnalyze}
                disabled={conversation.trim().length < 20 || isLoading}
                className="w-full h-12 text-base font-semibold bg-gradient-to-r from-purple-500 via-pink-500 to-violet-500 hover:from-purple-600 hover:via-pink-600 hover:to-violet-600 shadow-lg shadow-purple-500/25 touch-manipulation"
              >
                {isLoading ? (
                  <>
                    <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }}>
                      <Ghost className="w-5 h-5 mr-2" />
                    </motion.div>
                    Analyse en cours...
                  </>
                ) : (
                  <><Sparkles className="w-5 h-5 mr-2" />Analyser</>
                )}
              </Button>
              {conversation.trim().length > 0 && conversation.trim().length < 20 && (
                <p className="text-sm text-amber-500 text-center">Encore {20 - conversation.trim().length} caractères...</p>
              )}
            </CardContent>
          </Card>

          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }} className="mt-3">
            {isPremium ? (
              <div className="flex items-center justify-center gap-2 text-sm bg-yellow-50 dark:bg-yellow-950 py-2 px-4 rounded-full">
                <Crown className="w-4 h-4 text-yellow-500" />
                <span className="font-semibold text-yellow-600 dark:text-yellow-400">Premium Actif</span>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-1">
                <div className="flex items-center gap-2 text-sm">
                  <span className="text-muted-foreground">Analyses aujourd'hui:</span>
                  <span className={`font-bold ${remaining > 0 ? 'text-purple-500' : 'text-red-500'}`}>{remaining}/3</span>
                </div>
                <div className="w-full max-w-[100px] h-1.5 bg-muted rounded-full overflow-hidden">
                  <motion.div className="h-full bg-gradient-to-r from-purple-500 to-pink-500" animate={{ width: `${(remaining / 3) * 100}%` }} />
                </div>
              </div>
            )}
          </motion.div>
        </motion.div>
      </div>
    </div>
  )
}

// Results Page
function ResultsPage({ analysis, onReset, onPremium, onSaveToHistory }: { 
  analysis: AnalysisResult; onReset: () => void; onPremium: () => void; onSaveToHistory: (result: AnalysisResult) => void 
}) {
  const [copied, setCopied] = useState(false)
  const [activeTab, setActiveTab] = useState('overview')
  const { toast } = useToast()

  useEffect(() => { onSaveToHistory(analysis) }, [analysis, onSaveToHistory])

  const handleShare = async () => {
    const shareText = `👻 GhostMeter - Mon analyse:\n\n"${analysis.punchline}"\n\n❤️ Intérêt: ${Math.round(analysis.interestScore)}%\n⚠️ Manipulation: ${Math.round(analysis.manipulationScore)}%\n👻 Ghosting: ${Math.round(analysis.ghostingScore)}%\n\n${analysis.badges.join(' ')}\n\nAnalyse ta conversation sur GhostMeter !`

    try {
      if (navigator.share) {
        await navigator.share({ title: 'GhostMeter - Mon analyse', text: shareText })
      } else {
        await navigator.clipboard.writeText(shareText)
        setCopied(true)
        toast({ title: "Copié ! 📋", description: "Tu peux maintenant partager ton résultat" })
        setTimeout(() => setCopied(false), 2000)
      }
    } catch {
      toast({ title: "Erreur", description: "Impossible de partager", variant: "destructive" })
    }
  }

  const getScoreColor = (score: number, type: 'good' | 'bad') => {
    if (type === 'good') return score >= 70 ? '#22c55e' : score >= 40 ? '#eab308' : '#ef4444'
    return score >= 70 ? '#ef4444' : score >= 40 ? '#eab308' : '#22c55e'
  }

  return (
    <div className="flex flex-col min-h-screen pt-16 pb-4">
      <div className="flex-1 p-4 overflow-y-auto">
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="max-w-lg mx-auto space-y-4">
          
          {/* Punchline */}
          <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
            <div className="inline-block bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 py-2 rounded-full text-lg font-bold shadow-lg">
              "{analysis.punchline}"
            </div>
          </motion.div>

          {/* Badges */}
          <div className="flex flex-wrap gap-2 justify-center">
            {analysis.badges.map((badge, i) => (
              <Badge key={i} variant="secondary" className="text-sm px-3 py-1 bg-gradient-to-r from-purple-100 to-pink-100 dark:from-purple-900 dark:to-pink-900">
                {badge}
              </Badge>
            ))}
          </div>

          {/* Scores */}
          <Card className="border-2 border-purple-200 dark:border-purple-800">
            <CardContent className="pt-4">
              <div className="grid grid-cols-3 gap-2 justify-items-center mb-4">
                <ScoreCircle score={analysis.interestScore} label="Intérêt" icon="❤️" color={getScoreColor(analysis.interestScore, 'good')} delay={0.1} />
                <ScoreCircle score={analysis.manipulationScore} label="Manipulation" icon="⚠️" color={getScoreColor(analysis.manipulationScore, 'bad')} delay={0.2} />
                <ScoreCircle score={analysis.ghostingScore} label="Ghosting" icon="👻" color={getScoreColor(analysis.ghostingScore, 'bad')} delay={0.3} />
              </div>
              <Separator className="mb-3" />
              <div className="text-center">
                <p className="text-xs text-muted-foreground mb-1">Score Global</p>
                <span className="text-4xl font-bold bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">
                  {analysis.overallScore}
                </span>
                <span className="text-xl text-muted-foreground">/100</span>
              </div>
            </CardContent>
          </Card>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-4 h-10">
              <TabsTrigger value="overview" className="text-xs">Vue</TabsTrigger>
              <TabsTrigger value="stats" className="text-xs">Stats</TabsTrigger>
              <TabsTrigger value="messages" className="text-xs">Messages</TabsTrigger>
              <TabsTrigger value="flags" className="text-xs">Flags</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="mt-3 space-y-3">
              {/* Evolution */}
              <EvolutionChart evolution={analysis.evolutionScore} />
              
              {/* Quick Stats */}
              <StatsCards stats={analysis.conversationStats} />
              
              {/* Personality Insight */}
              <Card className="bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-950 dark:to-pink-950">
                <CardContent className="pt-3">
                  <p className="text-xs text-muted-foreground mb-1"> Analyse de personnalité</p>
                  <p className="text-sm">{analysis.personalityInsight}</p>
                </CardContent>
              </Card>
              
              {/* Advice */}
              <Card className="bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-950 dark:to-pink-950">
                <CardHeader className="pb-1 pt-3">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-purple-500" />
                    Conseil du Ghost
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <p className="text-sm">{analysis.advice}</p>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="stats" className="mt-3 space-y-3">
              <Card>
                <CardHeader className="pb-2 pt-3">
                  <CardTitle className="text-sm">Statistiques de conversation</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-muted/50 rounded-lg p-3">
                      <p className="text-xs text-muted-foreground">Total messages</p>
                      <p className="text-2xl font-bold">{analysis.conversationStats.totalMessages}</p>
                    </div>
                    <div className="bg-muted/50 rounded-lg p-3">
                      <p className="text-xs text-muted-foreground">Questions posées</p>
                      <p className="text-2xl font-bold">{analysis.conversationStats.userQuestionCount + analysis.conversationStats.otherQuestionCount}</p>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <p className="text-xs font-medium">Répartition des messages</p>
                    <div className="flex h-4 rounded-full overflow-hidden bg-muted">
                      <div 
                        className="bg-purple-500" 
                        style={{ width: `${(analysis.conversationStats.userMessages / analysis.conversationStats.totalMessages) * 100}%` }}
                      />
                      <div 
                        className="bg-pink-500" 
                        style={{ width: `${(analysis.conversationStats.otherMessages / analysis.conversationStats.totalMessages) * 100}%` }}
                      />
                    </div>
                    <div className="flex justify-between text-xs">
                      <span>Toi: {analysis.conversationStats.userMessages} ({Math.round((analysis.conversationStats.userMessages / analysis.conversationStats.totalMessages) * 100)}%)</span>
                      <span>Lui/Elle: {analysis.conversationStats.otherMessages} ({Math.round((analysis.conversationStats.otherMessages / analysis.conversationStats.totalMessages) * 100)}%)</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <p className="text-xs font-medium">Utilisation d'emojis</p>
                    <div className="flex justify-between text-sm">
                      <span>😍 Toi: {analysis.conversationStats.emojiUsage.user}</span>
                      <span>😍 Lui/Elle: {analysis.conversationStats.emojiUsage.other}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="messages" className="mt-3 space-y-2">
              <p className="text-xs text-muted-foreground mb-2">Analyse message par message ({analysis.messageAnalysis.length} messages)</p>
              <div className="space-y-2 max-h-[400px] overflow-y-auto">
                {analysis.messageAnalysis.map((msg, i) => (
                  <MessageAnalysisCard key={i} analysis={msg} index={i} />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="flags" className="mt-3 space-y-3">
              {analysis.greenFlagsDetected.length > 0 && (
                <Card className="border-green-200 dark:border-green-800">
                  <CardHeader className="pb-2 pt-3">
                    <CardTitle className="text-sm flex items-center gap-2 text-green-600 dark:text-green-400">
                      ✅ Green Flags ({analysis.greenFlagsDetected.length})
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-1">
                      {analysis.greenFlagsDetected.map((flag, i) => (
                        <li key={i} className="text-sm flex items-start gap-2">
                          <span className="text-green-500">•</span>
                          {flag}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              )}
              
              {analysis.redFlagsDetected.length > 0 && (
                <Card className="border-red-200 dark:border-red-800">
                  <CardHeader className="pb-2 pt-3">
                    <CardTitle className="text-sm flex items-center gap-2 text-red-600 dark:text-red-400">
                      🚩 Red Flags ({analysis.redFlagsDetected.length})
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-1">
                      {analysis.redFlagsDetected.map((flag, i) => (
                        <li key={i} className="text-sm flex items-start gap-2">
                          <span className="text-red-500">•</span>
                          {flag}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>

          {/* Action Buttons */}
          <div className="grid grid-cols-3 gap-2 pt-2">
            <Button onClick={onReset} variant="outline" className="h-11 gap-1 touch-manipulation">
              <RefreshCw className="w-4 h-4" />
              <span className="text-xs">Nouveau</span>
            </Button>
            <Button onClick={handleShare} variant="outline" className="h-11 gap-1 touch-manipulation">
              {copied ? <Check className="w-4 h-4 text-green-500" /> : <Share2 className="w-4 h-4" />}
              <span className="text-xs">{copied ? 'Copié!' : 'Partager'}</span>
            </Button>
            <Button onClick={onPremium} className="h-11 gap-1 bg-gradient-to-r from-purple-500 to-pink-500 touch-manipulation">
              <Crown className="w-4 h-4" />
              <span className="text-xs">Premium</span>
            </Button>
          </div>
        </motion.div>
      </div>
    </div>
  )
}

// History Page
function HistoryPage({ history, onClear, onSelectResult }: { 
  history: AnalysisResult[]; onClear: () => void; onSelectResult: (result: AnalysisResult) => void 
}) {
  if (history.length === 0) {
    return (
      <div className="flex flex-col min-h-screen pt-16 pb-4">
        <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
          <History className="w-16 h-16 text-muted-foreground/50 mb-4" />
          <h2 className="text-xl font-semibold mb-2">Aucun historique</h2>
          <p className="text-muted-foreground">Tes analyses apparaîtront ici</p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col min-h-screen pt-16 pb-4">
      <div className="flex-1 p-4 overflow-y-auto">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold">Historique</h2>
          <Button variant="ghost" size="sm" onClick={onClear} className="text-red-500 touch-manipulation">
            <Trash2 className="w-4 h-4 mr-1" />Effacer
          </Button>
        </div>
        <div className="space-y-3">
          {history.map((item, index) => {
            const platform = platforms.find(p => p.id === item.platform)
            const context = relationshipContexts.find(c => c.id === item.context)
            return (
              <Card key={index} className="cursor-pointer active:scale-[0.98] transition-transform touch-manipulation" onClick={() => onSelectResult(item)}>
                <CardContent className="p-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-full bg-gradient-to-br ${platform?.gradient || 'from-gray-400 to-gray-600'} flex items-center justify-center text-white text-lg`}>
                      {platform?.icon || '📱'}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-sm truncate">{item.punchline}</span>
                        {context && <span>{context.emoji}</span>}
                      </div>
                      <div className="flex gap-2 text-xs text-muted-foreground">
                        <span>❤️ {Math.round(item.interestScore)}%</span>
                        <span>⚠️ {Math.round(item.manipulationScore)}%</span>
                        <span>👻 {Math.round(item.ghostingScore)}%</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-lg font-bold">{item.overallScore}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>
    </div>
  )
}

// Premium Page
function PremiumPage({ onBack }: { onBack: () => void }) {
  return (
    <div className="flex flex-col min-h-screen pt-16 pb-4">
      <div className="flex-1 p-4 overflow-y-auto">
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-md mx-auto">
          <div className="text-center mb-6">
            <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring" }}>
              <Crown className="w-16 h-16 mx-auto text-yellow-500" />
            </motion.div>
            <h1 className="text-2xl font-bold mt-3 bg-gradient-to-r from-yellow-500 to-orange-500 bg-clip-text text-transparent">
              GhostMeter Premium
            </h1>
            <p className="text-muted-foreground text-sm">Passe au niveau supérieur 👻</p>
          </div>

          <Card className="border-2 border-yellow-200 dark:border-yellow-800 shadow-xl mb-4">
            <CardContent className="pt-4 space-y-3">
              {[ 
                { icon: <Zap className="w-5 h-5 text-yellow-500" />, title: 'Analyses illimitées', desc: 'Plus de limite quotidienne' },
                { icon: <Shield className="w-5 h-5 text-green-500" />, title: 'Conseils détaillés', desc: 'Stratégies personnalisées' },
                { icon: <TrendingUp className="w-5 h-5 text-blue-500" />, title: 'Historique complet', desc: 'Compare tes conversations' },
                { icon: <Sparkles className="w-5 h-5 text-purple-500" />, title: 'Badges exclusifs', desc: 'Débloque des récompenses' },
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-3 p-2 rounded-lg bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-950 dark:to-pink-950">
                  {item.icon}
                  <div><p className="font-medium text-sm">{item.title}</p><p className="text-xs text-muted-foreground">{item.desc}</p></div>
                </div>
              ))}
            </CardContent>
          </Card>

          <div className="space-y-3 mb-4">
            <Card className="overflow-hidden border-2 border-purple-200 dark:border-purple-800">
              <div className="bg-gradient-to-r from-purple-500 to-pink-500 p-2 text-center text-white font-bold text-sm">⭐ PLUS POPULAIRE</div>
              <CardContent className="pt-4 text-center">
                <p className="text-3xl font-bold">4€<span className="text-base font-normal text-muted-foreground">/mois</span></p>
                <p className="text-xs text-muted-foreground mt-1">Annule quand tu veux</p>
                <Button className="w-full mt-3 bg-gradient-to-r from-purple-500 to-pink-500 touch-manipulation">
                  <Crown className="w-4 h-4 mr-2" />S'abonner
                </Button>
              </CardContent>
            </Card>
            <Card className="border border-muted">
              <CardContent className="pt-4 text-center">
                <p className="text-base font-semibold">Pack Analyse Crush</p>
                <p className="text-2xl font-bold mt-1">1€<span className="text-sm font-normal text-muted-foreground">/analyse</span></p>
                <p className="text-xs text-muted-foreground mt-1">Sans abonnement</p>
                <Button variant="outline" className="w-full mt-3 touch-manipulation">Acheter</Button>
              </CardContent>
            </Card>
          </div>
        </motion.div>
      </div>
    </div>
  )
}

// Analyzing Page
function AnalyzingPage() {
  const messages = ["Lecture des vibes... 👻", "Analyse des emojis...", "Détection des red flags... 🚩", "Calcul du ghosting...", "Le fantôme réfléchit...", "Presque fini..."]
  const [messageIndex, setMessageIndex] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => setMessageIndex((prev) => (prev + 1) % messages.length), 1500)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="flex flex-col min-h-screen pt-16">
      <div className="flex-1 flex flex-col items-center justify-center p-8">
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center">
          <motion.div animate={{ scale: [1, 1.2, 1], rotate: [0, 10, -10, 0] }} transition={{ duration: 2, repeat: Infinity }}>
            <GhostLogo size={100} animated={false} />
          </motion.div>
          <motion.p key={messageIndex} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="text-lg mt-6 text-muted-foreground">
            {messages[messageIndex]}
          </motion.p>
          <div className="mt-4 flex justify-center gap-1">
            {[0, 1, 2].map((i) => (
              <motion.div key={i} animate={{ y: [0, -10, 0] }} transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.2 }} className="w-2 h-2 rounded-full bg-gradient-to-r from-purple-500 to-pink-500" />
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  )
}

// Main App
export default function Home() {
  const [appState, setAppState] = useState<AppState>('home')
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const { toast } = useToast()
  const { remaining, isPremium } = useRateLimit(3)
  const { history, addToHistory, clearHistory } = useHistory()

  const handleAnalyze = async (conversation: string, platform: string, context: string) => {
    setIsLoading(true)
    setAppState('analyzing')

    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ conversation, platform, context })
      })

      const data = await response.json()

      if (data.success && data.analysis) {
        const resultWithContext = { ...data.analysis, platform, context }
        setAnalysis(resultWithContext)
        setAppState('results')
      } else {
        throw new Error(data.error || 'Erreur inconnue')
      }
    } catch (error) {
      console.error('Analysis error:', error)
      toast({ title: "Erreur 👻", description: error instanceof Error ? error.message : "L'analyse a échoué. Réessaie !", variant: "destructive" })
      setAppState('home')
    } finally {
      setIsLoading(false)
    }
  }

  const handleReset = () => { setAnalysis(null); setAppState('home') }
  const handleNavigate = (state: AppState) => setAppState(state)

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 dark:from-gray-950 dark:via-purple-950 dark:to-gray-950">
      <MobileHeader onMenuClick={() => setMenuOpen(true)} showBack={appState === 'premium' || appState === 'history'} onBack={handleReset} title={appState === 'premium' ? 'Premium' : appState === 'history' ? 'Historique' : undefined} />
      <MobileMenu isOpen={menuOpen} onClose={() => setMenuOpen(false)} onNavigate={handleNavigate} remaining={remaining} isPremium={isPremium} />

      <AnimatePresence mode="wait">
        {appState === 'home' && <HomePage key="home" onAnalyze={handleAnalyze} isLoading={isLoading} onPremium={() => setAppState('premium')} remaining={remaining} isPremium={isPremium} />}
        {appState === 'analyzing' && <AnalyzingPage key="analyzing" />}
        {appState === 'results' && analysis && <ResultsPage key="results" analysis={analysis} onReset={handleReset} onPremium={() => setAppState('premium')} onSaveToHistory={addToHistory} />}
        {appState === 'premium' && <PremiumPage key="premium" onBack={handleReset} />}
        {appState === 'history' && <HistoryPage key="history" history={history} onClear={clearHistory} onSelectResult={(result) => { setAnalysis(result); setAppState('results') }} />}
      </AnimatePresence>
    </div>
  )
}
